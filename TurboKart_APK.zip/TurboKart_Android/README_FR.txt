TURBO KART 3D — PROJET ANDROID
==============================

Ce projet enveloppe le jeu HTML original dans une application Android plein écran.
Il conserve le code du jeu fourni (circuits, voitures, IA, menus, HUD, modes et commandes tactiles).

IMPORTANT
---------
Ce ZIP est un PROJET SOURCE Android, pas encore un APK compilé.
La compilation Android nécessite Android SDK + Gradle. L'environnement de création du ZIP
ne possède pas le SDK Android et ne peut pas télécharger les outils nécessaires.

CONDITIONS DE FONCTIONNEMENT
----------------------------
- Android 6.0 ou plus récent (API 23+).
- Connexion Internet nécessaire au démarrage du jeu : le jeu HTML original charge Three.js
  et ses modules depuis jsDelivr. La police Google est également externe.
- Orientation paysage, plein écran, accélération matérielle et stockage local activés.

CRÉER L'APK DANS LE CLOUD (SANS INSTALLER ANDROID STUDIO SUR LE TÉLÉPHONE)
-------------------------------------------------------------------------
Le dossier .github/workflows contient un workflow de compilation automatique.
1. Créer un dépôt GitHub vide depuis le navigateur du téléphone.
2. Y envoyer le contenu de ce ZIP (les dossiers app, .github et les fichiers Gradle).
3. Ouvrir l'onglet Actions du dépôt.
4. Choisir « Build Turbo Kart APK », puis « Run workflow » si le lancement n'a pas déjà eu lieu.
5. Quand l'exécution est terminée, ouvrir le résultat « Turbo-Kart-APK » dans Artifacts et télécharger
   le fichier app-debug.apk.
6. Ouvrir l'APK sur le téléphone et autoriser l'installation depuis cette source si Android le demande.

COMPATIBILITÉ / LIMITES
-----------------------
- Le jeu reste le jeu HTML/Three.js original : il n'a pas été réécrit en C++.
- Le moteur 3D et les effets sont chargés depuis Internet ; sans connexion, le jeu ne démarre pas.
- Les performances dépendent du navigateur WebView et du GPU du téléphone.
- Le projet est configuré pour installation directe (APK debug), pas pour publication Play Store.
